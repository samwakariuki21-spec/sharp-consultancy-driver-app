# Store Release Guide

## Current Best Path

Start by launching the app online as a PWA. Once the live URL works, package it for stores.

## Google Play Store

Best packaging route for this app: Android Trusted Web Activity.

What you need:
- Google Play Console developer account.
- A live HTTPS app URL.
- App icon, screenshots, short description, full description, privacy policy URL, and support email.
- Android package name, for example `com.sharpconsultancy.driverjobs`.

Current official cost note:
- Google Play Console has a US$25 one-time registration fee.

Technical path:
1. Deploy the app online first.
2. Use Bubblewrap or Android Studio Trusted Web Activity packaging.
3. Generate an Android App Bundle `.aab`.
4. Upload to Google Play Console.
5. Complete testing/review requirements.

## Apple App Store

Best packaging route: Capacitor or native iOS WebView wrapper.

What you need:
- Apple Developer Program membership.
- A Mac with Xcode for signing/building.
- A live HTTPS app URL.
- Privacy policy URL, screenshots, app icon, support email, and App Store metadata.

Current official cost note:
- Apple Developer Program membership is US$99 per year.

Important:
- Apple App Review can reject apps that are only a thin website wrapper. To improve approval chances, add mobile-native value such as push notifications, saved login, document upload, location permissions, or offline-first features.

## Recommended Order

1. Put the website online with Render.
2. Add real Africa's Talking, Resend, and AI keys in Render environment variables.
3. Add a privacy policy page.
4. Test the PWA on Android and iPhone browsers.
5. Package Android first for Google Play.
6. Package iOS after the live app is stable.

