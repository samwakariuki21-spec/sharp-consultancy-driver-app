from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlencode
from urllib.request import Request, urlopen
import json
import os


ROOT = Path(__file__).resolve().parent
DATA = ROOT / "data"
DB = DATA / "db.json"
DEFAULT_DB = {"jobs": [], "requests": [], "reviews": [], "notifications": [], "calendarEvents": []}


def load_env():
    env_path = ROOT / ".env"
    if not env_path.exists():
        return
    for line in env_path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        os.environ.setdefault(key.strip(), value.strip())


def configured(value):
    return bool(value and not value.startswith("your_"))


def read_db():
    DATA.mkdir(exist_ok=True)
    if not DB.exists():
        DB.write_text(json.dumps(DEFAULT_DB, indent=2), encoding="utf-8")
    try:
        data = json.loads(DB.read_text(encoding="utf-8"))
        return {**DEFAULT_DB, **data}
    except Exception:
        return dict(DEFAULT_DB)


def write_db(data):
    DATA.mkdir(exist_ok=True)
    DB.write_text(json.dumps({**DEFAULT_DB, **data}, indent=2), encoding="utf-8")


def normalize_phone(phone):
    cleaned = "".join(ch for ch in str(phone or "") if ch.isdigit() or ch == "+")
    if cleaned.startswith("+"):
        return cleaned
    if cleaned.startswith("0"):
        return "+254" + cleaned[1:]
    if cleaned.startswith("254"):
        return "+" + cleaned
    return cleaned


def post_json(url, headers, payload):
    req = Request(url, data=json.dumps(payload).encode("utf-8"), headers=headers, method="POST")
    with urlopen(req, timeout=15) as response:
        return {"ok": 200 <= response.status < 300, "status": response.status, "result": response.read().decode("utf-8", "ignore")}


def send_sms(to, message):
    api_key = os.environ.get("AFRICASTALKING_API_KEY", "")
    username = os.environ.get("AFRICASTALKING_USERNAME", "sandbox")
    sender = os.environ.get("AFRICASTALKING_SENDER_ID", "")
    phone = normalize_phone(to)
    if not configured(api_key) or not phone:
        return {"skipped": True, "reason": "Missing AFRICASTALKING_API_KEY or recipient phone."}
    body = {"username": username, "to": phone, "message": message}
    if sender:
        body["from"] = sender
    data = urlencode(body).encode("utf-8")
    req = Request(
        "https://api.africastalking.com/version1/messaging",
        data=data,
        headers={"apiKey": api_key, "Content-Type": "application/x-www-form-urlencoded", "Accept": "application/json"},
        method="POST",
    )
    with urlopen(req, timeout=15) as response:
        return {"ok": 200 <= response.status < 300, "status": response.status, "result": response.read().decode("utf-8", "ignore")}


def send_email(to, subject, message):
    api_key = os.environ.get("RESEND_API_KEY", "")
    sender = os.environ.get("EMAIL_FROM", "Sharp Consultancy <onboarding@resend.dev>")
    if not configured(api_key) or not to:
        return {"skipped": True, "reason": "Missing RESEND_API_KEY or recipient email."}
    return post_json(
        "https://api.resend.com/emails",
        {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        {"from": sender, "to": [to], "subject": subject, "text": message},
    )


def local_chat(persona, question):
    text = question.lower()
    name = "Angela" if persona == "Angela" else "Samuel"
    if any(word in text for word in ["document", "require", "psv", "good conduct"]):
        return f"{name}: Drivers need ID, valid driving licence, PSV licence or badge where required, Certificate of Good Conduct, medical fitness certificate, experience proof, CV/profile, referees, and training certificates where available."
    if any(word in text for word in ["sms", "email", "notification"]):
        return f"{name}: SMS uses Africa's Talking and email uses Resend. Add real credentials in .env, then restart the backend."
    if any(word in text for word in ["payment", "quick", "400", "m-pesa"]):
        return f"{name}: Quick Search is KSH 400. Drivers choose a payment method and add their payment reference in the request form."
    if any(word in text for word in ["location", "route", "area", "neighborhood", "neighbour"]):
        return f"{name}: Drivers can type any Kenyan county, route, area, or neighborhood, then search within or outside that location."
    return f"{name}: I can help anyone with driver jobs, employer hiring, documents, payments, interviews, SMS/email notifications, and using this portal."


def ai_chat(persona, question):
    api_key = os.environ.get("OPENAI_API_KEY", "")
    model = os.environ.get("OPENAI_MODEL", "")
    if not configured(api_key) or not configured(model):
        return {"provider": "local", "answer": local_chat(persona, question)}
    prompt = (
        f"You are {persona}, an assistant for Sharp Consultancy Limited. "
        "Help anyone use the Kenyan school-driver jobs portal. "
        "Be concise and practical. Contact: 0711608769, samwakariuki21@gmail.com. "
        "Quick Search costs KSH 400."
    )
    try:
        result = post_json(
            "https://api.openai.com/v1/responses",
            {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            {"model": model, "instructions": prompt, "input": question},
        )
        payload = json.loads(result.get("result", "{}"))
        return {"provider": "openai", "answer": payload.get("output_text") or local_chat(persona, question)}
    except Exception as exc:
        return {"provider": "local", "answer": local_chat(persona, question), "error": str(exc)}


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def json_response(self, status, payload):
        data = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def read_json(self):
        length = int(self.headers.get("Content-Length", "0"))
        if not length:
            return {}
        return json.loads(self.rfile.read(length).decode("utf-8"))

    def do_GET(self):
        if self.path == "/api/health":
            self.json_response(200, {
                "ok": True,
                "sms": configured(os.environ.get("AFRICASTALKING_API_KEY", "")),
                "email": configured(os.environ.get("RESEND_API_KEY", "")),
                "ai": configured(os.environ.get("OPENAI_API_KEY", "")) and configured(os.environ.get("OPENAI_MODEL", "")),
            })
            return
        if self.path == "/api/state":
            self.json_response(200, read_db())
            return
        super().do_GET()

    def do_PUT(self):
        if self.path == "/api/state":
            write_db(self.read_json())
            self.json_response(200, {"ok": True})
            return
        self.json_response(404, {"ok": False})

    def do_POST(self):
        if self.path == "/api/chat":
            body = self.read_json()
            self.json_response(200, {"ok": True, **ai_chat(body.get("persona", "Samuel"), body.get("question", ""))})
            return
        if self.path == "/api/notify":
            body = self.read_json()
            db = read_db()
            notice = {**body, "delivery": []}
            recipients = notice.get("recipients", {})
            owner_phone = os.environ.get("OWNER_PHONE", "0711608769")
            owner_email = os.environ.get("OWNER_EMAIL", "samwakariuki21@gmail.com")
            if recipients.get("ownerSms"):
                notice["delivery"].append({"channel": "owner_sms", **send_sms(owner_phone, notice.get("message", ""))})
            if recipients.get("ownerEmail"):
                notice["delivery"].append({"channel": "owner_email", **send_email(owner_email, notice.get("title", "Notification"), notice.get("message", ""))})
            if recipients.get("driverSms"):
                notice["delivery"].append({"channel": "driver_sms", **send_sms(recipients.get("driverPhone"), notice.get("message", ""))})
            if recipients.get("driverEmail"):
                notice["delivery"].append({"channel": "driver_email", **send_email(recipients.get("driverEmail"), notice.get("title", "Notification"), notice.get("message", ""))})
            db["notifications"] = [notice] + db.get("notifications", [])
            write_db(db)
            self.json_response(200, {"ok": True, "notice": notice})
            return
        self.json_response(404, {"ok": False})


if __name__ == "__main__":
    load_env()
    port = int(os.environ.get("PORT", "4180"))
    host = os.environ.get("HOST", "127.0.0.1")
    print(f"Sharp Consultancy app running at http://{host}:{port}/")
    ThreadingHTTPServer((host, port), Handler).serve_forever()
