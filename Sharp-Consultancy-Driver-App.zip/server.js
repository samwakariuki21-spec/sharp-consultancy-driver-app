const http = require("node:http");
const fsSync = require("node:fs");
const fs = require("node:fs/promises");
const path = require("node:path");
const { URL } = require("node:url");

const root = __dirname;
const dataDir = path.join(root, "data");
const dbPath = path.join(dataDir, "db.json");

loadEnvFile();
const port = Number(process.env.PORT || 4173);
const host = process.env.HOST || "0.0.0.0";

const mimeTypes = {
  ".html": "text/html; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".webmanifest": "application/manifest+json; charset=utf-8",
  ".svg": "image/svg+xml; charset=utf-8",
  ".pdf": "application/pdf"
};

const defaultDb = {
  jobs: [],
  requests: [],
  reviews: [],
  notifications: [],
  calendarEvents: []
};

function env(name, fallback = "") {
  return process.env[name] || fallback;
}

function isConfigured(value) {
  return Boolean(value && !String(value).startsWith("your_"));
}

function localChatReply({ persona = "Samuel", question = "" }) {
  const text = question.toLowerCase();
  const prefix = persona === "Angela" ? "Angela" : "Samuel";

  if (text.includes("document") || text.includes("require") || text.includes("psv") || text.includes("good conduct")) {
    return `${prefix}: School drivers should prepare a National ID, valid driving licence, PSV licence or badge where required, Certificate of Good Conduct, medical fitness certificate, proof of experience, CV/profile, referees, and training certificates where available.`;
  }
  if (text.includes("sms") || text.includes("email") || text.includes("notification")) {
    return `${prefix}: SMS uses Africa's Talking and email uses Resend. Add real credentials in the local .env file, restart the backend, then the notification queue can send through those providers.`;
  }
  if (text.includes("payment") || text.includes("quick") || text.includes("400") || text.includes("m-pesa")) {
    return `${prefix}: Quick Search is KSH 400. Drivers can choose M-Pesa, Airtel Money, Card, or Bank Transfer and add a payment reference on the request form.`;
  }
  if (text.includes("interview") || text.includes("approve") || text.includes("reject")) {
    return `${prefix}: Employers can set an interview date, approve, or reject a driver request from the Employers portal. Confirming an interview prepares SMS and email messages for the driver.`;
  }
  if (text.includes("location") || text.includes("route") || text.includes("area") || text.includes("neighbour") || text.includes("neighborhood")) {
    return `${prefix}: Drivers can type any Kenyan county, route, area, or neighborhood, then search within or outside that location.`;
  }
  if (text.includes("contact") || text.includes("phone") || text.includes("call")) {
    return `${prefix}: Sharp Consultancy Limited can be contacted on 0711608769 or samwakariuki21@gmail.com.`;
  }
  return `${prefix}: I can help with driver job search, employer hiring, required documents, payments, interviews, SMS/email notifications, and how to use the portal.`;
}

async function answerWithAi({ persona, question }) {
  const apiKey = env("OPENAI_API_KEY");
  const model = env("OPENAI_MODEL");

  if (!isConfigured(apiKey) || !isConfigured(model)) {
    return { provider: "local", answer: localChatReply({ persona, question }) };
  }

  const db = await readDb();
  const system = [
    `You are ${persona}, an assistant for Sharp Consultancy Limited.`,
    "Help drivers, employers, school staff, and visitors use the school-driver jobs portal.",
    "Be concise, warm, practical, and do not claim that SMS/email is active unless credentials are configured.",
    "Known contact: 0711608769, samwakariuki21@gmail.com.",
    "Quick Search costs KSH 400.",
    "School driver documents include ID, valid driving licence, PSV licence/badge where required, Certificate of Good Conduct, medical fitness certificate, experience proof, CV/profile, referees, and training certificates.",
    `Current jobs count: ${(db.jobs || []).length}. Current request count: ${(db.requests || []).length}.`
  ].join("\n");

  const response = await fetch("https://api.openai.com/v1/responses", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      model,
      instructions: system,
      input: question
    })
  });

  const payload = await response.json();
  if (!response.ok) {
    return { provider: "local", answer: localChatReply({ persona, question }), error: payload.error?.message || "AI provider error" };
  }

  const answer = payload.output_text ||
    payload.output?.flatMap((item) => item.content || []).map((item) => item.text || "").join(" ").trim() ||
    localChatReply({ persona, question });

  return { provider: "openai", answer };
}

function loadEnvFile() {
  const envPath = path.join(root, ".env");
  if (!fsSync.existsSync(envPath)) return;
  const contents = fsSync.readFileSync(envPath, "utf8");
  for (const line of contents.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed || trimmed.startsWith("#")) continue;
    const index = trimmed.indexOf("=");
    if (index === -1) continue;
    const key = trimmed.slice(0, index).trim();
    const value = trimmed.slice(index + 1).trim();
    if (key && process.env[key] === undefined) process.env[key] = value;
  }
}

function normalizeKenyaPhone(phone) {
  const cleaned = String(phone || "").replace(/[^\d+]/g, "");
  if (cleaned.startsWith("+")) return cleaned;
  if (cleaned.startsWith("0")) return `+254${cleaned.slice(1)}`;
  if (cleaned.startsWith("254")) return `+${cleaned}`;
  return cleaned;
}

async function ensureDb() {
  await fs.mkdir(dataDir, { recursive: true });
  try {
    await fs.access(dbPath);
  } catch {
    await fs.writeFile(dbPath, JSON.stringify(defaultDb, null, 2));
  }
}

async function readDb() {
  await ensureDb();
  try {
    return { ...defaultDb, ...JSON.parse(await fs.readFile(dbPath, "utf8")) };
  } catch {
    return { ...defaultDb };
  }
}

async function writeDb(db) {
  await ensureDb();
  await fs.writeFile(dbPath, JSON.stringify({ ...defaultDb, ...db }, null, 2));
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const text = Buffer.concat(chunks).toString("utf8");
  return text ? JSON.parse(text) : {};
}

function sendJson(res, status, payload) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(payload));
}

async function sendSms({ to, message }) {
  const apiKey = env("AFRICASTALKING_API_KEY");
  const username = env("AFRICASTALKING_USERNAME", "sandbox");
  const from = env("AFRICASTALKING_SENDER_ID");
  const normalizedTo = normalizeKenyaPhone(to);

  if (!isConfigured(apiKey) || !normalizedTo) {
    return { skipped: true, reason: "Missing AFRICASTALKING_API_KEY or recipient phone." };
  }

  const body = new URLSearchParams({
    username,
    to: normalizedTo,
    message
  });
  if (from) body.set("from", from);

  const response = await fetch("https://api.africastalking.com/version1/messaging", {
    method: "POST",
    headers: {
      apiKey,
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json"
    },
    body
  });

  const result = await response.text();
  return { ok: response.ok, status: response.status, result };
}

async function sendEmail({ to, subject, message }) {
  const apiKey = env("RESEND_API_KEY");
  const from = env("EMAIL_FROM", "Sharp Consultancy <onboarding@resend.dev>");

  if (!isConfigured(apiKey) || !to) {
    return { skipped: true, reason: "Missing RESEND_API_KEY or recipient email." };
  }

  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      from,
      to: [to],
      subject,
      text: message
    })
  });

  const result = await response.text();
  return { ok: response.ok, status: response.status, result };
}

async function handleNotification(payload) {
  const db = await readDb();
  const ownerPhone = env("OWNER_PHONE", "0711608769");
  const ownerEmail = env("OWNER_EMAIL", "samwakariuki21@gmail.com");
  const notice = {
    id: payload.id || `note-${Date.now()}`,
    type: payload.type || "Notification",
    title: payload.title || "Sharp Consultancy notification",
    message: payload.message || "",
    createdAt: payload.createdAt || new Date().toISOString(),
    recipients: payload.recipients || {},
    delivery: []
  };

  const recipients = notice.recipients;
  if (recipients.ownerSms) {
    notice.delivery.push({ channel: "owner_sms", ...(await sendSms({ to: ownerPhone, message: notice.message })) });
  }
  if (recipients.ownerEmail) {
    notice.delivery.push({ channel: "owner_email", ...(await sendEmail({ to: ownerEmail, subject: notice.title, message: notice.message })) });
  }
  if (recipients.driverSms) {
    notice.delivery.push({ channel: "driver_sms", ...(await sendSms({ to: recipients.driverPhone, message: notice.message })) });
  }
  if (recipients.driverEmail) {
    notice.delivery.push({ channel: "driver_email", ...(await sendEmail({ to: recipients.driverEmail, subject: notice.title, message: notice.message })) });
  }
  if (recipients.schoolEmail) {
    notice.delivery.push({ channel: "school_email", ...(await sendEmail({ to: recipients.schoolEmail, subject: notice.title, message: notice.message })) });
  }

  db.notifications = [notice, ...(db.notifications || [])].slice(0, 200);
  await writeDb(db);
  return notice;
}

async function serveStatic(req, res, pathname) {
  const safePath = pathname === "/" ? "/index.html" : pathname;
  const filePath = path.normalize(path.join(root, safePath));

  if (!filePath.startsWith(root)) {
    res.writeHead(403);
    res.end("Forbidden");
    return;
  }

  try {
    const data = await fs.readFile(filePath);
    res.writeHead(200, {
      "Content-Type": mimeTypes[path.extname(filePath)] || "application/octet-stream"
    });
    res.end(data);
  } catch {
    res.writeHead(404);
    res.end("Not found");
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);

  try {
    if (url.pathname === "/api/health") {
      sendJson(res, 200, {
        ok: true,
        sms: isConfigured(env("AFRICASTALKING_API_KEY")),
        email: isConfigured(env("RESEND_API_KEY")),
        ai: isConfigured(env("OPENAI_API_KEY")) && isConfigured(env("OPENAI_MODEL"))
      });
      return;
    }

    if (url.pathname === "/api/state" && req.method === "GET") {
      sendJson(res, 200, await readDb());
      return;
    }

    if (url.pathname === "/api/state" && req.method === "PUT") {
      const body = await readBody(req);
      await writeDb({ ...defaultDb, ...body });
      sendJson(res, 200, { ok: true });
      return;
    }

    if (url.pathname === "/api/notify" && req.method === "POST") {
      const notice = await handleNotification(await readBody(req));
      sendJson(res, 200, { ok: true, notice });
      return;
    }

    if (url.pathname === "/api/chat" && req.method === "POST") {
      const result = await answerWithAi(await readBody(req));
      sendJson(res, 200, { ok: true, ...result });
      return;
    }

    await serveStatic(req, res, url.pathname);
  } catch (error) {
    sendJson(res, 500, { ok: false, error: error.message });
  }
});

server.listen(port, host, () => {
  const displayHost = host === "0.0.0.0" ? "127.0.0.1" : host;
  console.log(`Sharp Consultancy app running at http://${displayHost}:${port}/`);
});
